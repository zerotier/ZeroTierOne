Retired Code and Miscellaneous Junk
======

This directory is for old code that isn't used but we don't want to lose track of, and for anything else random like debug scripts.
