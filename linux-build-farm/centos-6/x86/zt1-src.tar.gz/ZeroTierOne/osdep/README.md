OS-Dependent and OS-Interface Things
======

This folder contains stuff that interfaces with the base operating system
like Phy for network access and the various OS-specific Ethernet tap
drivers.
