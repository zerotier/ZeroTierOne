World Definitions and Generator Code
======

This little bit of code is used to generate world updates. Ordinary users probably will never need this unless they want to test or experiment.

See mkworld.cpp for documentation. To build from this directory use 'source ./build.sh'.

