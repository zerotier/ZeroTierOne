ZeroTier Newer-Spiffier Command Line Interface
======

This will be the future home of our new unified CLI for ZeroTier One, controllers, and Central (my.zerotier.com etc.).

IT IS NOT DONE AND DOES NOT WORK EVEN A LITTLE BIT. GO AWAY.
