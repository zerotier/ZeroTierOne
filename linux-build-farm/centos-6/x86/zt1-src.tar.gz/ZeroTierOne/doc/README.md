Manual Pages and Other Documentation
=====

Use "./build.sh" to build the manual pages. You'll need NodeJS and npm installed.
